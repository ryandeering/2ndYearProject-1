#line 1 "Regexp/Common/CC.pm"
package Regexp::Common::CC;

use 5.10.0;

use strict;
use warnings;
no  warnings 'syntax';

use Regexp::Common qw /pattern clean no_defaults/;
use Regexp::Common::_support qw /luhn/;

our $VERSION = '2017060201';

my @cards = (
    # Name           Prefix                    Length           mod 10
    [Mastercard   =>   '5[1-5]',                16,                1],
    [Visa         =>   '4',                     [13, 16],          1],
    [Amex         =>   '3[47]',                 15,                1],
   # Carte Blanche
   ['Diners Club' =>   '3(?:0[0-5]|[68])',      14,                1],
    [Discover     =>   '6011',                  16,                1],
    [enRoute      =>   '2(?:014|149)',          15,                0],
    [JCB          => [['3',                     16,                1],
                      ['2131|1800',             15,                1]]],
);


foreach my $card (@cards) {
    my ($name, $prefix, $length, $mod) = @$card;

    # Skip the harder ones for now.
    next if ref $prefix || ref $length;
    next unless $mod;

    my $times = $length + $mod;
    pattern name    => [CC => $name],
            create  => sub {
                use re 'eval';
                qr <((?=($prefix))[0-9]{$length})
                    (?(?{Regexp::Common::_support::luhn $1})|(?!))>x
            }
    ;
}




1;

__END__

#line 124
