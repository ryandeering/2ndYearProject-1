#line 1 "Regexp/Common/URI.pm"
package Regexp::Common::URI;

use 5.10.0;

use strict;
use warnings;
no  warnings 'syntax';

use Exporter ();

our @ISA       = qw /Exporter/;
our @EXPORT_OK = qw /register_uri/;

use Regexp::Common qw /pattern clean no_defaults/;

our $VERSION = '2017060201';

# Use 'require' here, not 'use', so we delay running them after we are compiled.
# We also do it using an 'eval'; this saves us from have repeated similar
# lines. The eval is further explained in 'perldoc -f require'.
my @uris = qw /fax file ftp gopher http pop prospero news tel telnet tv wais/;
foreach my $uri (@uris) {
    eval "require Regexp::Common::URI::$uri";
    die $@ if $@;
}

my %uris;

sub register_uri {
    my ($scheme, $uri) = @_;
    $uris {$scheme} = $uri;
}

pattern name    => [qw (URI)],
        create  => sub {my $uri =  join '|' => values %uris;
                           $uri =~ s/\(\?k:/(?:/g;
                      "(?k:$uri)";
        },
        ;

1;

__END__

#line 144
