#line 1 "Regexp/Common/SEN.pm"
package Regexp::Common::SEN;

use 5.10.0;

use strict;
use warnings;
no  warnings 'syntax';

use Regexp::Common qw /pattern clean no_defaults/;

our $VERSION = '2017060201';

#line 27

# http://www.ssa.gov/history/ssn/geocard.html
pattern name   => [qw /SEN USA SSN -sep=-/],
        create => sub {
            my $sep = $_ [1] {-sep};
            "(?k:(?k:[1-9][0-9][0-9]|0[1-9][0-9]|00[1-9])$sep"   .
                "(?k:[1-9][0-9]|0[1-9])$sep"                     .
                "(?k:[1-9][0-9][0-9][0-9]|0[1-9][0-9][0-9]|"     .
                                         "00[1-9][0-9]|000[1-9]))"
        },
        ;

#line 55

1;

__END__

#line 148
