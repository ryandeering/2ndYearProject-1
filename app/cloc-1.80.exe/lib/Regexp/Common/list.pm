#line 1 "Regexp/Common/list.pm"
package Regexp::Common::list;

use 5.10.0;

use strict;
use warnings;
no  warnings 'syntax';

use Regexp::Common qw /pattern clean no_defaults/;

our $VERSION = '2017060201';

sub gen_list_pattern {
    my ($pat, $sep, $lsep) = @_;
    $lsep = $sep unless defined $lsep;
    return "(?k:(?:(?:$pat)(?:$sep))*(?:$pat)(?k:$lsep)(?:$pat))";
}

my $defpat = '.*?\S';
my $defsep = '\s*,\s*';

pattern name   => ['list', "-pat=$defpat", "-sep=$defsep", '-lastsep'],
        create => sub {gen_list_pattern (@{$_[1]}{-pat, -sep, -lastsep})},
        ;

pattern name   => ['list', 'conj', '-word=(?:and|or)'],
        create => sub {gen_list_pattern($defpat, $defsep,
                                        '\s*,?\s*'.$_[1]->{-word}.'\s*');
                  },
        ;

pattern name   => ['list', 'and'],
        create => sub {gen_list_pattern ($defpat, $defsep, '\s*,?\s*and\s*')},
        ;

pattern name   => ['list', 'or'],
        create => sub {gen_list_pattern ($defpat, $defsep, '\s*,?\s*or\s*')},
        ;


1;

__END__

#line 161
