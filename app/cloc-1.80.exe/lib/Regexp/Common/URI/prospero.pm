#line 1 "Regexp/Common/URI/prospero.pm"
package Regexp::Common::URI::prospero;

use Regexp::Common               qw /pattern clean no_defaults/;
use Regexp::Common::URI          qw /register_uri/;
use Regexp::Common::URI::RFC1738 qw /$host $port $ppath $fieldname $fieldvalue
                                     $fieldspec/;

use strict;
use warnings;

use vars qw /$VERSION/;
$VERSION = '2017060201';


my $scheme = 'prospero';
my $uri    = "(?k:(?k:$scheme)://(?k:$host)(?::(?k:$port))?" .
             "/(?k:$ppath)(?k:$fieldspec*))";

register_uri $scheme => $uri;

pattern name    => [qw (URI prospero)],
        create  => $uri,
        ;

1;

__END__

#line 119
