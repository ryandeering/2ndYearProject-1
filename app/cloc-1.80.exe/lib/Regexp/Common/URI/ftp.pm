#line 1 "Regexp/Common/URI/ftp.pm"
package Regexp::Common::URI::ftp;

use Regexp::Common               qw /pattern clean no_defaults/;
use Regexp::Common::URI          qw /register_uri/;
use Regexp::Common::URI::RFC2396 qw /$host $port $ftp_segments $userinfo
                                     $userinfo_no_colon/;

use strict;
use warnings;

use vars qw /$VERSION/;
$VERSION = '2017060201';


my $ftp_uri = "(?k:(?k:ftp)://(?:(?k:$userinfo)(?k:)\@)?(?k:$host)" .
              "(?::(?k:$port))?(?k:/(?k:(?k:$ftp_segments)"         .
              "(?:;type=(?k:[AIai]))?))?)";

my $ftp_uri_password =
              "(?k:(?k:ftp)://(?:(?k:$userinfo_no_colon)"           .
              "(?::(?k:$userinfo_no_colon))?\@)?(?k:$host)"         .
              "(?::(?k:$port))?(?k:/(?k:(?k:$ftp_segments)"         .
              "(?:;type=(?k:[AIai]))?))?)";

register_uri FTP => $ftp_uri;

pattern name    => [qw (URI FTP), "-type=[AIai]", "-password="],
        create  => sub {
            my $uri    =  exists $_ [1] -> {-password} &&
                        !defined $_ [1] -> {-password} ? $ftp_uri_password
                                                       : $ftp_uri;
            my $type   =  $_ [1] -> {-type};
            $uri       =~ s/\[AIai\]/$type/;
            $uri;
        }
        ;


1;

__END__

#line 207
