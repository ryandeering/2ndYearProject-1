#line 1 "Regexp/Common/URI/fax.pm"
package Regexp::Common::URI::fax;

use Regexp::Common               qw /pattern clean no_defaults/;
use Regexp::Common::URI          qw /register_uri/;
use Regexp::Common::URI::RFC2806 qw /$fax_subscriber 
                                     $fax_subscriber_no_future/;

use strict;
use warnings;

use vars qw /$VERSION/;
$VERSION = '2017060201';


my $fax_scheme  = 'fax';
my $fax_uri     = "(?k:(?k:$fax_scheme):(?k:$fax_subscriber))";
my $fax_uri_nf  = "(?k:(?k:$fax_scheme):(?k:$fax_subscriber_no_future))";

register_uri $fax_scheme => $fax_uri;

pattern name    => [qw (URI fax)],
        create  => $fax_uri
        ;

pattern name    => [qw (URI fax nofuture)],
        create  => $fax_uri_nf
        ;

1;

__END__

#line 129
