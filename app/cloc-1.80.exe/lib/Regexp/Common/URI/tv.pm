#line 1 "Regexp/Common/URI/tv.pm"
# TV URLs. 
# Internet draft: draft-zigmond-tv-url-03.txt

package Regexp::Common::URI::tv;

use Regexp::Common               qw /pattern clean no_defaults/;
use Regexp::Common::URI          qw /register_uri/;
use Regexp::Common::URI::RFC2396 qw /$hostname/;

use strict;
use warnings;

use vars qw /$VERSION/;
$VERSION = '2017060201';


my $tv_scheme = 'tv';
my $tv_url    = "(?k:(?k:$tv_scheme):(?k:$hostname)?)";

register_uri $tv_scheme => $tv_url;

pattern name    => [qw (URI tv)],
        create  => $tv_url,
        ;

1;

__END__

#line 114
