#line 1 "Regexp/Common/URI/http.pm"
package Regexp::Common::URI::http;

use Regexp::Common               qw /pattern clean no_defaults/;
use Regexp::Common::URI          qw /register_uri/;
use Regexp::Common::URI::RFC2396 qw /$host $port $path_segments $query/;

use strict;
use warnings;

use vars qw /$VERSION/;
$VERSION = '2017060201';


my $http_uri = "(?k:(?k:http)://(?k:$host)(?::(?k:$port))?"           .
               "(?k:/(?k:(?k:$path_segments)(?:[?](?k:$query))?))?)";

my $https_uri = $http_uri; $https_uri =~ s/http/https?/;

register_uri HTTP => $https_uri;

pattern name    => [qw (URI HTTP), "-scheme=http"],
        create  => sub {
            my $scheme =  $_ [1] -> {-scheme};
            my $uri    =  $http_uri;
               $uri    =~ s/http/$scheme/;
            $uri;
        }
        ;

1;

__END__

#line 147
