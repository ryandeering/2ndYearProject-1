#line 1 "Regexp/Common/URI/pop.pm"
package Regexp::Common::URI::pop;

use Regexp::Common               qw /pattern clean no_defaults/;
use Regexp::Common::URI          qw /register_uri/;
use Regexp::Common::URI::RFC1738 qw /$host $port/;
use Regexp::Common::URI::RFC2384 qw /$enc_user $enc_auth_type/;

use strict;
use warnings;

use vars qw /$VERSION/;
$VERSION = '2017060201';


my $scheme = "pop";
my $uri    = "(?k:(?k:$scheme)://(?:(?k:$enc_user)"     .  
             "(?:;AUTH=(?k:[*]|$enc_auth_type))?\@)?"   .
             "(?k:$host)(?::(?k:$port))?)";

register_uri $scheme => $uri;

pattern name    => [qw (URI POP)],
        create  => $uri,
        ;

1;

__END__

#line 119
