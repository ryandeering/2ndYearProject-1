#line 1 "Regexp/Common/URI/tel.pm"
package Regexp::Common::URI::tel;

use Regexp::Common               qw /pattern clean no_defaults/;
use Regexp::Common::URI          qw /register_uri/;
use Regexp::Common::URI::RFC2806 qw /$telephone_subscriber 
                                     $telephone_subscriber_no_future/;

use strict;
use warnings;

use vars qw /$VERSION/;
$VERSION = '2017060201';


my $tel_scheme  = 'tel';
my $tel_uri     = "(?k:(?k:$tel_scheme):(?k:$telephone_subscriber))";
my $tel_uri_nf  = "(?k:(?k:$tel_scheme):(?k:$telephone_subscriber_no_future))";

register_uri $tel_scheme => $tel_uri;

pattern name    => [qw (URI tel)],
        create  => $tel_uri
        ;

pattern name    => [qw (URI tel nofuture)],
        create  => $tel_uri_nf
        ;

1;

__END__

#line 129
