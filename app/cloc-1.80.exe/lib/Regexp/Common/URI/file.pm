#line 1 "Regexp/Common/URI/file.pm"
package Regexp::Common::URI::file;

use Regexp::Common               qw /pattern clean no_defaults/;
use Regexp::Common::URI          qw /register_uri/;
use Regexp::Common::URI::RFC1738 qw /$host $fpath/;

use strict;
use warnings;

use vars qw /$VERSION/;
$VERSION = '2017060201';


my $scheme = 'file';
my $uri    = "(?k:(?k:$scheme)://(?k:(?k:(?:$host|localhost)?)" .
             "(?k:/(?k:$fpath))))";

register_uri $scheme => $uri;

pattern name    => [qw (URI file)],
        create  => $uri,
        ;

1;

__END__

#line 121
