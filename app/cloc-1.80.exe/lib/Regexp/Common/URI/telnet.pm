#line 1 "Regexp/Common/URI/telnet.pm"
package Regexp::Common::URI::telnet;

use Regexp::Common               qw /pattern clean no_defaults/;
use Regexp::Common::URI          qw /register_uri/;
use Regexp::Common::URI::RFC1738 qw /$user $password $host $port/;

use strict;
use warnings;

use vars qw /$VERSION/;
$VERSION = '2017060201';


my $telnet_uri = "(?k:(?k:telnet)://(?:(?k:(?k:$user)(?::(?k:$password))?)\@)?" 
               . "(?k:(?k:$host)(?::(?k:$port))?)(?k:/)?)";

register_uri telnet => $telnet_uri;

pattern name    => [qw (URI telnet)],
        create  => $telnet_uri,
        ;

1;

__END__

#line 132
